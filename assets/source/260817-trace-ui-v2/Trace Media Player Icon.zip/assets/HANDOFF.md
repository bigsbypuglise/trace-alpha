# Trace — Windows 11 redesign handoff

Design package: **windows11-redesign**
Accent: `#5AC8E8` (cyan) · Type: Segoe UI Variable · Appearance: dark only

---

## Read this first — what is a swap and what is not

This delivery has two very different halves. Please don't treat the whole thing as an asset swap.

**1. The glyph assets ARE a drop-in swap.** Every interface glyph is delivered as `name.svg` + `name-24.png` + `name-48.png` at exact pixel sizes, transparent background, white fill (the app's brightness multiplier does hover/pressed at draw time). Dropping `assets/interface/**` over the existing files updates the art for the existing aliases with **no code, no `.qrc`, no size changes.** Run `scripts/verify_trace_assets.py assets/interface` — it should exit 0.

**2. The player REDESIGN is a development project, not a swap.** The mockups show an edge-to-edge Fluent transport strip, a floating (content-into-titlebar) top chrome, a new control set, a custom timeline, switchable readout units, and an idle animation. Each of these re-opens a signed-off decision or needs new behaviour. They are listed under "Not a straight swap" below with the cost attached, so the call stays yours.

---

## Folders delivered

```
assets/
  interface/                      drop-in working copies (correct alias names)
    transport/  play, pause, rewind, fast-forward, share      (svg + -24 + -48)
    window/     fullscreen-enter, fullscreen-exit             (svg + -24 + -48)
    common/     copy-path, show-in-explorer, copy-lucidlink   (svg + -24 + -48)
  branding/app-icon/
    svg/        trace-windows.svg, trace-macos.svg
    png/windows/  trace-{16,24,32,48,64,256}.png
    png/macos/    trace-{16,32,64,128,256,512,1024}.png
    (compile trace.ico / trace.icns from these — see below)
  source/windows11-redesign/      the untouched master package — never edited by the app
    transport/ window/ common/    all glyphs incl. future volume, loop
    branding/                     app-icon svg + png sets
    mockups/                      01 windowed · 02 fullscreen · 03 empty (PNG)
```

## Alias reminder (do not "fix" these)

The two fullscreen files keep disk names that differ from their resource alias:

| file on disk | resource alias |
|---|---|
| `fullscreen-enter-24.png` / `-48.png` | `fullscreen-24.png` / `fullscreen-48.png` |
| `fullscreen-exit-24.png` / `-48.png` | `exit-fullscreen-24.png` / `exit-fullscreen-48.png` |

Everything else is `name → name`.

## No interaction-state art

No hover / pressed / disabled variants are supplied on purpose — those are the draw-time brightness multiplier (×1.35 / ×0.72). The glyphs are drawn as solid, high-contrast silhouettes so they survive being brightened a third and dimmed a quarter over unknown footage.

---

## Not a straight swap — decisions for the owner

| item | why it costs dev time |
|---|---|
| **Edge-to-edge transport strip** (56 px, full window width) replaces the 460×84 floating panel | panel dimensions change → layout work + re-test both render backends |
| **New control set** (rewind, fast-forward, volume, loop, share) + timeline + m:ss readouts | new controls need behaviour first; the old glyph set (prev/next-clip, frame-step, pip, external, more) is retired |
| **rewind / fast-forward** | in the ten-glyph contract, but only wire the art to buttons once those buttons shuttle/skip. "Both" (frame step + time skip) was the intent — confirm before shipping. Until then they live in `source/` only. |
| **volume / loop** | features not yet shipped — delivered to `source/common/` only; do **not** copy into `assets/interface/` until they exist |
| **Idle "prism" animation** on the empty screen | the mark stays fully opaque while its color rolls (spectral edge sweeps, glow shifts hue over ~18 s). In the mockups this is SVG SMIL. Qt's SVG module isn't linked and doesn't play SMIL, so in-app it needs a small gradient animator (a `QVariantAnimation` on the stops, or a tiny shader) — cheap, but more than a static PNG. Honor reduced-motion by holding static. This is a nice-to-have, not required for the swap. |
| **Translucent title bar + acrylic transport** | uses backdrop blur (Mica/Acrylic). Provide a solid fallback (`#14161A` ~96%) when transparency effects are disabled in Windows Settings |
| **Full-bleed video under a floating title bar** | `ExtendsContentIntoTitleBar` — a windowing change |
| **App icon `.ico` / `.icns`** | compile from the provided PNG sets + SVGs (multi-resolution). Not delivered as compiled binaries. |

## Geometry in the mockups (for the redesign, if pursued)

Strip 56 px, edge-to-edge · play/pause 40 px, other controls 36 px, radius 6 · timeline track 4 px (6 px on hover), thumb 13 px (16 px scrubbing) · accent only on the played track + thumb ring.

## After any art swap

Re-run the cross-backend comparison (`overlay.ps1` / `banddiff.ps1`) and pixel-snap — an art-only change can still differ between the two renderers at a fractional offset.
