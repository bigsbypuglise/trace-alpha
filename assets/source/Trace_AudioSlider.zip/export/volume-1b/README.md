# Volume control — option 1b (inline expand)

Behaviour: hovering/clicking the speaker slides out a short horizontal slider (~74 px) in the transport row itself; collapses after ~1.5 s idle. Scroll wheel over the button also adjusts.

## Artwork (white, transparent, 24-grid — same contract as the other glyphs)
- volume.svg / volume-24.png / volume-48.png — rest state (speaker + waves)
- volume-open.svg / -24 / -48 — while the slider is expanded (speaker only, waves replaced by the slider)
- volume-muted.svg / -24 / -48 — muted (speaker + ×)

## Not artwork (code-drawn)
The slider itself uses the existing timeline drawing: track 4 px rgba(255,255,255,0.22), fill #5AC8E8, thumb 11 px white. No PNG needed.
Hover/pressed remain the draw-time brightness multiplier — no state variants shipped.
